import 'package:flutter/material.dart';
import 'package:travel_app/presentation/pages/login-signup/signup/components/body.dart';

class SignUpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
