# Adventure_app

I'am developing an adventure app with Flutter and Firebase, to show how to apply  best practices,  in Flutter to build a scalable app.
Still in progress....
## Some pictures of the App

![259228637_1321874704913984_8494662416812869928_n](https://user-images.githubusercontent.com/40029149/148287844-58fed95a-9e87-4fa4-91ac-28af4ea89781.jpg)
![257978092_313526307030532_4347847891675271782_n](https://user-images.githubusercontent.com/40029149/148287813-710f2cb1-59f0-4dae-870b-63e80e87a7c3.jpg)
![258788614_438380731139403_8262609146416658807_n](https://user-images.githubusercontent.com/40029149/148287831-c9167299-c15a-4ef0-88e2-f7d926225659.jpg)

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
